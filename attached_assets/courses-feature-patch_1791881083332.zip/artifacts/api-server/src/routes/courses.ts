import { hasPermission } from "@workspace/auth-shared";
import {
  coursesTable,
  db,
  entitlementsTable,
  lessonsTable,
  mediaAssetsTable,
  modulesTable,
} from "@workspace/db";
import { and, asc, eq, gt, inArray, isNull, lte, or } from "drizzle-orm";
import { Router, type IRouter, type Request } from "express";
import { sendError } from "../lib/errors";
import { publicCache } from "../lib/http";
import { signCourseAssetRead } from "../lib/courseStorage";
import { requireAuth } from "../middlewares/rbac";

const router: IRouter = Router();
const playbackTtlSeconds = 2 * 60 * 60;

type CourseRow = typeof coursesTable.$inferSelect;
type LessonRow = typeof lessonsTable.$inferSelect;

async function findPublishedCourse(slug: string) {
  const [course] = await db
    .select()
    .from(coursesTable)
    .where(and(eq(coursesTable.slug, slug), eq(coursesTable.status, "published"), isNull(coursesTable.deletedAt)))
    .limit(1);
  return course;
}

async function loadOutline(courseId: string) {
  const modules = await db
    .select()
    .from(modulesTable)
    .where(and(eq(modulesTable.courseId, courseId), isNull(modulesTable.deletedAt)))
    .orderBy(asc(modulesTable.position), asc(modulesTable.createdAt));
  if (modules.length === 0) return [];
  const lessons = await db
    .select()
    .from(lessonsTable)
    .where(
      and(
        inArray(lessonsTable.moduleId, modules.map((m) => m.id)),
        eq(lessonsTable.status, "published"),
        isNull(lessonsTable.deletedAt),
      ),
    )
    .orderBy(asc(lessonsTable.position), asc(lessonsTable.createdAt));
  return modules.map((m) => ({
    id: m.id,
    title: m.title,
    lessons: lessons
      .filter((l) => l.moduleId === m.id)
      .map((l) => ({
        id: l.id,
        title: l.title,
        type: l.type,
        durationSeconds: l.durationSeconds,
        isFreePreview: l.isFreePreview,
      })),
  }));
}

/** Free course, free-preview lesson, admin, or an active entitlement for the course's exam. */
async function canAccess(req: Request, course: CourseRow, lesson?: Pick<LessonRow, "isFreePreview">) {
  if (course.isFree) return true;
  if (lesson?.isFreePreview) return true;
  if (!req.auth) return false;
  if (hasPermission(req.auth.user.role, "admin:access")) return true;
  if (!course.examId) return false;
  const now = new Date();
  const [row] = await db
    .select({ id: entitlementsTable.id })
    .from(entitlementsTable)
    .where(
      and(
        eq(entitlementsTable.userId, req.auth.user.id),
        eq(entitlementsTable.examId, course.examId),
        isNull(entitlementsTable.revokedAt),
        lte(entitlementsTable.startsAt, now),
        or(isNull(entitlementsTable.endsAt), gt(entitlementsTable.endsAt, now)),
      ),
    )
    .limit(1);
  return Boolean(row);
}

router.get("/courses", async (_req, res) => {
  publicCache(res);
  const courses = await db
    .select()
    .from(coursesTable)
    .where(and(eq(coursesTable.status, "published"), isNull(coursesTable.deletedAt)))
    .orderBy(asc(coursesTable.position), asc(coursesTable.title));
  const items = await Promise.all(
    courses.map(async (course) => {
      const outline = await loadOutline(course.id);
      return {
        id: course.id,
        slug: course.slug,
        title: course.title,
        summary: course.summary,
        isFree: course.isFree,
        moduleCount: outline.length,
        lessonCount: outline.reduce((total, m) => total + m.lessons.length, 0),
      };
    }),
  );
  res.json({ items });
});

router.get("/courses/:slug", async (req, res) => {
  const course = await findPublishedCourse(String(req.params.slug));
  if (!course) return void sendError(res, 404, "not_found", "Course not found.");
  const [modules, hasAccess] = await Promise.all([loadOutline(course.id), canAccess(req, course)]);
  res.setHeader("Cache-Control", "private, no-store");
  res.json({
    id: course.id,
    slug: course.slug,
    title: course.title,
    summary: course.summary,
    description: course.description,
    isFree: course.isFree,
    hasAccess,
    modules,
  });
});

router.get("/courses/:slug/lessons/:lessonId", requireAuth, async (req, res) => {
  const course = await findPublishedCourse(String(req.params.slug));
  if (!course) return void sendError(res, 404, "not_found", "Course not found.");

  const [row] = await db
    .select({ lesson: lessonsTable })
    .from(lessonsTable)
    .innerJoin(modulesTable, eq(modulesTable.id, lessonsTable.moduleId))
    .where(
      and(
        eq(lessonsTable.id, String(req.params.lessonId)),
        eq(modulesTable.courseId, course.id),
        eq(lessonsTable.status, "published"),
        isNull(lessonsTable.deletedAt),
        isNull(modulesTable.deletedAt),
      ),
    )
    .limit(1);
  if (!row) return void sendError(res, 404, "not_found", "Lesson not found.");
  const lesson = row.lesson;

  if (!(await canAccess(req, course, lesson))) {
    return void sendError(res, 403, "no_access", "This lesson is not included in your plan.");
  }

  let asset: { url: string; filename: string; mimeType: string | null } | null = null;
  if (lesson.assetId) {
    const [media] = await db
      .select()
      .from(mediaAssetsTable)
      .where(and(eq(mediaAssetsTable.id, lesson.assetId), isNull(mediaAssetsTable.deletedAt)))
      .limit(1);
    if (media?.storageKey && media.processing === "ready") {
      try {
        asset = {
          url: await signCourseAssetRead(media.storageKey, playbackTtlSeconds),
          filename: media.filename,
          mimeType: media.mimeType,
        };
      } catch (error) {
        req.log.error({ err: error, lessonId: lesson.id }, "Failed to sign lesson media URL");
      }
    }
  }

  res.setHeader("Cache-Control", "private, no-store");
  res.json({
    id: lesson.id,
    title: lesson.title,
    type: lesson.type,
    body: lesson.body,
    durationSeconds: lesson.durationSeconds,
    course: { slug: course.slug, title: course.title },
    asset,
  });
});

export default router;
