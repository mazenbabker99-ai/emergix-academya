import { ArrowLeft, Download } from 'lucide-react';
import { Link, useParams } from 'wouter';
import { ErrorState, PageSkeleton } from '@/components/shared/DataState';
import { Prose } from '@/components/shared/Prose';
import { SiteLayout } from '@/components/shared/SiteLayout';
import { CourseApiError, useLessonDetail } from '@/features/courses/api';
import { usePageMeta } from '@/lib/usePageMeta';

export default function LessonPage() {
  const { slug = '', lessonId = '' } = useParams<{ slug: string; lessonId: string }>();
  const lesson = useLessonDetail(slug, lessonId);
  usePageMeta(lesson.data?.title ?? 'Lesson', 'Course lesson.');
  const back = <Link href={`/courses/${slug}`} className="course-back"><ArrowLeft size={15} /> Back to course</Link>;
  if (lesson.isLoading) return <SiteLayout><main className="section"><div className="container"><PageSkeleton /></div></main></SiteLayout>;
  if (lesson.isError || !lesson.data) {
    const locked = lesson.error instanceof CourseApiError && lesson.error.status === 403;
    return <SiteLayout><main className="section"><div className="container course-page">{back}<ErrorState title={locked ? 'This lesson is not included in your plan' : 'We could not load this lesson'} /></div></main></SiteLayout>;
  }
  const { title, type, body, asset } = lesson.data;
  const mime = asset?.mimeType ?? '';
  return <SiteLayout><main className="section"><div className="container course-page">
    {back}
    <span className="eyebrow">{lesson.data.course.title}</span>
    <h1>{title}</h1>
    {asset && (type === 'video' || mime.startsWith('video/')) && <video className="lesson-player" controls controlsList="nodownload" playsInline preload="metadata" src={asset.url} />}
    {asset && (type === 'audio' || mime.startsWith('audio/')) && <audio className="lesson-audio" controls controlsList="nodownload" preload="metadata" src={asset.url} />}
    {asset && mime === 'application/pdf' && <iframe className="lesson-pdf" title={title} src={asset.url} />}
    {asset && !mime.startsWith('video/') && !mime.startsWith('audio/') && (
      <p><a className="btn btn-light" href={asset.url} target="_blank" rel="noopener noreferrer"><Download size={15} /> Open {asset.filename}</a></p>
    )}
    {body && <Prose text={body} />}
    {!asset && !body && <p>Content for this lesson will be added soon.</p>}
  </div></main></SiteLayout>;
}
