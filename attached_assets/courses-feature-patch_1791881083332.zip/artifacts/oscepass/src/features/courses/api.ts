import { useQuery } from '@tanstack/react-query';

export type CourseSummary = { id: string; slug: string; title: string; summary: string; isFree: boolean; moduleCount: number; lessonCount: number };
export type OutlineLesson = { id: string; title: string; type: 'video' | 'article' | 'pdf' | 'audio' | 'resource' | 'quiz'; durationSeconds: number | null; isFreePreview: boolean };
export type OutlineModule = { id: string; title: string; lessons: OutlineLesson[] };
export type CourseDetail = { id: string; slug: string; title: string; summary: string; description: string; isFree: boolean; hasAccess: boolean; modules: OutlineModule[] };
export type LessonDetail = {
  id: string; title: string; type: OutlineLesson['type']; body: string | null; durationSeconds: number | null;
  course: { slug: string; title: string };
  asset: { url: string; filename: string; mimeType: string | null } | null;
};

export class CourseApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

async function getJson<T>(path: string): Promise<T> {
  const response = await fetch(path, { credentials: 'include', headers: { Accept: 'application/json' } });
  if (!response.ok) {
    let message = 'Request failed.';
    try { message = (await response.json())?.message ?? message; } catch { /* ignore */ }
    throw new CourseApiError(response.status, message);
  }
  return response.json() as Promise<T>;
}

export const useCourseList = () =>
  useQuery({ queryKey: ['public-courses'], queryFn: async () => (await getJson<{ items: CourseSummary[] }>('/api/courses')).items });

export const useCourseDetail = (slug: string) =>
  useQuery({ queryKey: ['public-course', slug], queryFn: () => getJson<CourseDetail>(`/api/courses/${encodeURIComponent(slug)}`) });

export const useLessonDetail = (slug: string, lessonId: string) =>
  useQuery({
    queryKey: ['public-lesson', slug, lessonId],
    queryFn: () => getJson<LessonDetail>(`/api/courses/${encodeURIComponent(slug)}/lessons/${encodeURIComponent(lessonId)}`),
    retry: false,
  });
