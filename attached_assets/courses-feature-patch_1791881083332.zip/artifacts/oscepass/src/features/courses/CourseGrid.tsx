import { ArrowRight, BookOpen, Clock3 } from 'lucide-react';
import { Link } from 'wouter';
import { EmptyState, ErrorState, PageSkeleton } from '@/components/shared/DataState';
import { useCourseList } from './api';

export function CourseGrid() {
  const courses = useCourseList();
  if (courses.isLoading) return <PageSkeleton rows={3} label="Loading courses" />;
  if (courses.isError) return <ErrorState title="We could not load the courses" onRetry={() => void courses.refetch()} />;
  if (!courses.data?.length) return <EmptyState title="Courses are coming soon" text="New courses will appear here as soon as they are published." />;
  return <div className="content-grid">{courses.data.map((course) => (
    <article className="content-card" key={course.id} data-testid={`course-card-${course.slug}`}>
      <span className="icon-tile"><BookOpen size={21} /></span>
      <p className="eyebrow" style={{ margin: '17px 0 0', fontSize: '.65rem' }}>{course.isFree ? 'Free course' : 'Premium course'}</p>
      <h3>{course.title}</h3>
      <p>{course.summary || 'Structured lessons and practice for your exam preparation.'}</p>
      <p style={{ fontSize: '.75rem', color: '#74869a', display: 'flex', gap: 6, alignItems: 'center' }}><Clock3 size={13} /> {course.moduleCount} modules · {course.lessonCount} lessons</p>
      <Link className="btn btn-light" href={`/courses/${course.slug}`}>Open course <ArrowRight size={15} /></Link>
    </article>
  ))}</div>;
}
